package task.execption;

public class InvalidFoodDetailsException extends Exception{
	
    public InvalidFoodDetailsException(String message) {
        super(message);
    }
    
}
